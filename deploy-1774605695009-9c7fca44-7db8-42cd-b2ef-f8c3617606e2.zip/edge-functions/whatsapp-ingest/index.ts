// ===========================================
// WHATSAPP INGEST v2 — Property Upload + Claude AI + Social Templates
// ===========================================
// Agent sends photo + caption via WhatsApp →
//   1. Parse caption (price, beds, type, area)
//   2. Extract amenities
//   3. Claude generates professional description
//   4. Property listed on profile
//   5. Instagram + TikTok captions sent back to agent
// ===========================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ── Amenity Map ──
const AMENITY_MAP: Record<string, string> = {
  'private pool': 'Private Pool', 'infinity pool': 'Infinity Pool', 'pool': 'Pool', 'swimming pool': 'Pool',
  'sea view': 'Sea View', 'ocean view': 'Sea View', 'marina view': 'Marina View', 'landmark view': 'Landmark View',
  'burj khalifa view': 'Burj Khalifa View', 'burj view': 'Burj Khalifa View', 'palm view': 'Palm View',
  'golf view': 'Golf View', 'garden view': 'Garden View', 'city view': 'City View', 'canal view': 'Canal View',
  'lake view': 'Lake View', 'creek view': 'Creek View', 'full sea view': 'Full Sea View',
  'panoramic view': 'Panoramic View', 'skyline view': 'Skyline View',
  'gym': 'In-House Gym', 'gymnasium': 'In-House Gym', 'fitness': 'Fitness Center',
  'sauna': 'Sauna', 'spa': 'Spa', 'jacuzzi': 'Jacuzzi', 'concierge': 'Concierge',
  'garden': 'Private Garden', 'terrace': 'Terrace', 'rooftop': 'Rooftop Terrace',
  'balcony': 'Balcony', 'bbq': 'BBQ Area', 'playground': 'Kids Playground',
  'parking': 'Parking', 'garage': 'Private Garage', 'valet': 'Valet Parking',
  'maid room': "Maid's Room", 'maids room': "Maid's Room", "maid's room": "Maid's Room",
  'study': 'Study Room', 'storage': 'Storage Room', 'smart home': 'Smart Home',
  'furnished': 'Furnished', 'fully furnished': 'Fully Furnished', 'unfurnished': 'Unfurnished',
  'semi furnished': 'Semi-Furnished', 'upgraded': 'Upgraded', 'brand new': 'Brand New',
  'vacant': 'Vacant', 'high floor': 'High Floor', 'low floor': 'Low Floor', 'mid floor': 'Mid Floor',
  'corner unit': 'Corner Unit', 'duplex': 'Duplex', 'penthouse': 'Penthouse',
  'beach access': 'Beach Access', 'private beach': 'Private Beach', 'waterfront': 'Waterfront',
  'pet friendly': 'Pet Friendly',
};
const SORTED_AMENITY_KEYS = Object.keys(AMENITY_MAP).sort((a, b) => b.length - a.length);

function extractAmenities(text: string): string[] {
  const lower = text.toLowerCase();
  const found: string[] = [];
  const seen = new Set<string>();
  for (const key of SORTED_AMENITY_KEYS) {
    if (lower.includes(key)) {
      const label = AMENITY_MAP[key];
      if (!seen.has(label)) { seen.add(label); found.push(label); }
    }
  }
  return found.slice(0, 8);
}

// ── Property Caption Parser ──
function parsePropertyCaption(caption: string): {
  title: string; price: string | null; type: string | null;
  bedrooms: number | null; bathrooms: number | null;
  area: string | null; sqft: number | null; features: string[];
} {
  const text = caption.trim();
  if (!text) return { title: '', price: null, type: null, bedrooms: null, bathrooms: null, area: null, sqft: null, features: [] };

  // Price
  let price: string | null = null;
  const priceMatch = text.match(/(?:AED\s*)?(\d[\d,.]*)\s*(?:M(?:illion)?|K)?\s*(?:AED)?/i);
  if (priceMatch) {
    const raw = priceMatch[0].trim();
    if (/AED|M(?:illion)?|K/i.test(raw)) price = raw;
  }

  // Bedrooms & Bathrooms
  let bedrooms: number | null = null;
  const brMatch = text.match(/(\d+)\s*(?:BR|BHK|bed(?:room)?s?)/i);
  if (brMatch) bedrooms = parseInt(brMatch[1]);

  let bathrooms: number | null = null;
  const bathMatch = text.match(/(\d+)\s*(?:bath(?:room)?s?|BA)/i);
  if (bathMatch) bathrooms = parseInt(bathMatch[1]);

  // Sqft
  let sqft: number | null = null;
  const sqftMatch = text.match(/([\d,]+)\s*(?:sq\.?\s*ft|sqft|square\s*feet)/i);
  if (sqftMatch) sqft = parseInt(sqftMatch[1].replace(/,/g, ''));

  // Property type
  let type: string | null = null;
  const typePatterns: Record<string, RegExp> = {
    'Apartment': /apartment|apt|flat/i, 'Villa': /villa/i, 'Townhouse': /townhouse|town\s*house/i,
    'Penthouse': /penthouse/i, 'Studio': /studio/i, 'Duplex': /duplex/i,
    'Land': /plot|land/i, 'Office': /office/i, 'Retail': /retail|shop/i,
  };
  for (const [t, re] of Object.entries(typePatterns)) {
    if (re.test(text)) { type = t; break; }
  }

  // Area
  let area: string | null = null;
  const areaPatterns = ['Downtown', 'Marina', 'JBR', 'Palm Jumeirah', 'Palm', 'Business Bay', 'Creek Harbour',
    'JVC', 'JLT', 'DIFC', 'City Walk', 'MBR City', 'Dubai Hills', 'Emirates Hills', 'Arabian Ranches',
    'Damac Hills', 'Sports City', 'Motor City', 'Al Barsha', 'Jumeirah', 'Silicon Oasis',
    'International City', 'Discovery Gardens', 'Mirdif', 'Rashid Yachts', 'Emaar Beachfront',
    'Bluewaters', 'Dubai South', 'Town Square', 'Al Furjan', 'Sobha Hartland', 'Mohammed Bin Rashid City',
    'Dubai Creek', 'Tilal Al Ghaf', 'The Valley', 'Dubai Islands', 'Yas Island', 'Saadiyat'];
  for (const a of areaPatterns) {
    if (text.toLowerCase().includes(a.toLowerCase())) { area = a; break; }
  }

  // Amenities
  const features = extractAmenities(text);

  // Title (cleaned)
  let title = text;
  if (price) title = title.replace(price, '').trim();
  title = title.replace(/^[,\-–—·|/]+|[,\-–—·|/]+$/g, '').trim();
  if (!title) title = [type, bedrooms ? `${bedrooms}BR` : '', area].filter(Boolean).join(' ') || 'New Property';

  return { title, price, type, bedrooms, bathrooms, area, sqft, features };
}

// ── Claude AI Description Generator ──
async function generateListingWithClaude(parsed: ReturnType<typeof parsePropertyCaption>, agentName: string): Promise<{
  title: string; description: string; igCaption: string; tiktokCaption: string;
} | null> {
  const CLAUDE_KEY = Deno.env.get("ANTHROPIC_API_KEY");
  if (!CLAUDE_KEY) return null;

  const propertyInfo = [
    parsed.title,
    parsed.type ? `Type: ${parsed.type}` : '',
    parsed.bedrooms ? `${parsed.bedrooms} bedrooms` : '',
    parsed.bathrooms ? `${parsed.bathrooms} bathrooms` : '',
    parsed.sqft ? `${parsed.sqft} sqft` : '',
    parsed.area ? `Location: ${parsed.area}` : '',
    parsed.price ? `Price: ${parsed.price}` : '',
    parsed.features.length ? `Features: ${parsed.features.join(', ')}` : '',
  ].filter(Boolean).join('\n');

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": CLAUDE_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 800,
        messages: [{
          role: "user",
          content: `You are a Dubai luxury real estate copywriter. Given this property info from an agent's WhatsApp message, generate EXACTLY this JSON (no markdown, no code blocks, just raw JSON):

{"title":"<catchy 5-8 word listing title>","description":"<2-3 sentence luxury property description, emphasize lifestyle and location, mention specific features>","igCaption":"<Instagram caption: hook line + 2 sentences + 5 relevant hashtags like #DubaiRealEstate #LuxuryLiving etc + CTA 'Link in bio for details'>","tiktokCaption":"<TikTok caption: punchy hook + 1 sentence + 3 hashtags + CTA>"}

Property info:
${propertyInfo}
Agent: ${agentName}

Rules:
- Title must be compelling, not generic
- Description should sell the lifestyle, not just list specs
- Instagram caption should be scroll-stopping, use 1-2 relevant emojis
- TikTok caption should be punchy and short
- All in English
- Return ONLY valid JSON, nothing else`
        }]
      }),
    });

    if (!res.ok) {
      console.error("Claude API error:", res.status, await res.text());
      return null;
    }

    const data = await res.json();
    const text = data.content?.[0]?.text || "";

    // Parse JSON from response (handle potential markdown wrapping)
    const jsonStr = text.replace(/^```json?\s*/i, '').replace(/\s*```$/i, '').trim();
    const result = JSON.parse(jsonStr);

    return {
      title: result.title || parsed.title,
      description: result.description || "",
      igCaption: result.igCaption || "",
      tiktokCaption: result.tiktokCaption || "",
    };
  } catch (e) {
    console.error("Claude generation error:", e);
    return null;
  }
}

// ── WhatsApp Helpers ──
async function sendWhatsAppReply(to: string, text: string) {
  const WA_TOKEN = Deno.env.get("WHATSAPP_ACCESS_TOKEN");
  const WA_PHONE_ID = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID");
  if (!WA_TOKEN || !WA_PHONE_ID) {
    console.log("WhatsApp reply (not sent, no creds):", to, text);
    return;
  }
  try {
    await fetch(`https://graph.facebook.com/v18.0/${WA_PHONE_ID}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${WA_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: text } }),
    });
  } catch (e) {
    console.error("WhatsApp reply error:", e);
  }
}

async function downloadAndUploadImage(supabase: any, mediaId: string, agentSlug: string): Promise<string | null> {
  const WA_TOKEN = Deno.env.get("WHATSAPP_ACCESS_TOKEN");
  if (!WA_TOKEN) return null;

  const mediaRes = await fetch(`https://graph.facebook.com/v18.0/${mediaId}`, {
    headers: { Authorization: `Bearer ${WA_TOKEN}` }
  });
  const mediaData = await mediaRes.json();
  if (!mediaData.url) return null;

  const imgRes = await fetch(mediaData.url, { headers: { Authorization: `Bearer ${WA_TOKEN}` } });
  const imgBytes = new Uint8Array(await imgRes.arrayBuffer());
  const contentType = imgRes.headers.get('content-type') || 'image/jpeg';
  const ext = contentType.includes('png') ? 'png' : 'jpg';

  const fileName = `${agentSlug}/property-${Date.now()}.${ext}`;
  const { error: uploadErr } = await supabase.storage
    .from('agent-images')
    .upload(fileName, imgBytes, { contentType, upsert: true });

  if (uploadErr) { console.error("Storage upload error:", uploadErr); return null; }

  const { data: urlData } = supabase.storage.from('agent-images').getPublicUrl(fileName);
  return urlData.publicUrl;
}

// ── Main Handler ──
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type",
  "Content-Type": "application/json",
};

Deno.serve(async (req: Request) => {
  const url = new URL(req.url);

  // === WEBHOOK VERIFICATION (GET) ===
  if (req.method === "GET") {
    const mode = url.searchParams.get("hub.mode");
    const token = url.searchParams.get("hub.verify_token");
    const challenge = url.searchParams.get("hub.challenge");
    const VERIFY_TOKEN = Deno.env.get("WH_VERIFY_TOKEN") || "SELLING_DUBAI_WH_VERIFY";
    if (mode === "subscribe" && token === VERIFY_TOKEN) return new Response(challenge, { status: 200 });
    return new Response("Forbidden", { status: 403 });
  }

  if (req.method !== "POST") return new Response("OK", { status: 200 });

  try {
    const body = await req.json();
    const messages = body.entry?.[0]?.changes?.[0]?.value?.messages;
    if (!messages || messages.length === 0) {
      return new Response(JSON.stringify({ success: true }), { headers: CORS });
    }

    const msg = messages[0];
    const senderPhone = msg.from;
    const msgType = msg.type;

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Find agent by WhatsApp number
    const cleanPhone = senderPhone.replace(/[^0-9]/g, '');
    const { data: agent, error: agentErr } = await supabase
      .from("agents")
      .select("id, name, slug, whatsapp")
      .or(`whatsapp.eq.${cleanPhone},whatsapp.eq.+${cleanPhone},whatsapp.ilike.%${cleanPhone.slice(-9)}`)
      .single();

    if (agentErr || !agent) {
      await sendWhatsAppReply(senderPhone, "Hi! Your number isn't registered on SellingDubai yet. Visit sellingdubai-agents.netlify.app/join to create your profile first.");
      return new Response(JSON.stringify({ success: true }), { headers: CORS });
    }

    // === HANDLE IMAGE MESSAGE ===
    if (msgType === "image") {
      const imageId = msg.image?.id;
      const caption = msg.image?.caption || "";
      const parsed = parsePropertyCaption(caption);

      // Upload image
      let imageUrl: string | null = null;
      if (imageId) {
        try { imageUrl = await downloadAndUploadImage(supabase, imageId, agent.slug); }
        catch (e) { console.error("Image download error:", e); }
      }

      // Send "processing" message immediately so agent knows we got it
      await sendWhatsAppReply(senderPhone, "📸 Got it! Generating your listing...");

      // Generate AI description + social templates
      const aiResult = await generateListingWithClaude(parsed, agent.name);

      const finalTitle = aiResult?.title || parsed.title || "New Property";
      const finalDescription = aiResult?.description || "";

      // Parse price to number
      let priceNum: number | null = null;
      if (parsed.price) {
        const cleaned = parsed.price.replace(/[^0-9.]/g, '');
        let num = parseFloat(cleaned);
        if (/M(?:illion)?/i.test(parsed.price)) num *= 1000000;
        if (/K/i.test(parsed.price)) num *= 1000;
        if (!isNaN(num) && num > 0) priceNum = num;
      }

      // Create property
      const { data: prop, error: propErr } = await supabase
        .from("properties")
        .insert({
          agent_id: agent.id,
          title: finalTitle,
          description: finalDescription,
          price: priceNum,
          image_url: imageUrl,
          property_type: parsed.type || null,
          bedrooms: parsed.bedrooms || null,
          bathrooms: parsed.bathrooms || null,
          area_sqft: parsed.sqft || null,
          location: parsed.area || null,
          features: parsed.features.length > 0 ? parsed.features : null,
          source: 'whatsapp',
          is_active: true,
          status: 'just_listed',
        })
        .select()
        .single();

      if (propErr) {
        console.error("Property insert error:", propErr);
        await sendWhatsAppReply(senderPhone, "Sorry, there was an error listing your property. Try again.");
        return new Response(JSON.stringify({ success: true }), { headers: CORS });
      }

      // Build confirmation + social templates
      const profileUrl = `https://sellingdubai-agents.netlify.app/a/${agent.slug}`;
      let confirmMsg = `✅ *Listed!*\n\n*${finalTitle}*`;
      if (parsed.price) confirmMsg += `\nPrice: ${parsed.price}`;
      if (parsed.area) confirmMsg += `\n📍 ${parsed.area}`;
      if (parsed.features.length) confirmMsg += `\n✨ ${parsed.features.slice(0, 4).join(' · ')}`;
      if (finalDescription) confirmMsg += `\n\n${finalDescription}`;
      confirmMsg += `\n\n🔗 Live on your profile:\n${profileUrl}`;

      await sendWhatsAppReply(senderPhone, confirmMsg);

      // Send Instagram caption
      if (aiResult?.igCaption) {
        await sendWhatsAppReply(senderPhone,
          `📸 *Copy for Instagram:*\n\n${aiResult.igCaption}`
        );
      }

      // Send TikTok caption
      if (aiResult?.tiktokCaption) {
        await sendWhatsAppReply(senderPhone,
          `🎬 *Copy for TikTok:*\n\n${aiResult.tiktokCaption}`
        );
      }

      return new Response(JSON.stringify({ success: true }), { headers: CORS });
    }

    // === HANDLE TEXT MESSAGE ===
    if (msgType === "text") {
      const text = msg.text?.body?.toLowerCase() || "";

      if (text.includes("help") || text === "hi" || text === "hello") {
        await sendWhatsAppReply(senderPhone,
          `Hey ${agent.name}! 👋\n\nTo add a property:\n\n📸 *Send a photo* with a caption like:\n_Marina View 2BR, AED 2.5M, sea view, furnished_\n\nI'll create a professional listing with AI description + Instagram & TikTok captions ready to post.\n\nCommands:\n• *"my stats"* — profile analytics\n• *"my link"* — your profile link\n• *"remove last"* — remove last property\n• *"social"* — get social templates for your latest listing`
        );
      } else if (text.includes("my stats") || text.includes("stats") || text.includes("analytics")) {
        const thisMonthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();
        const { count: views } = await supabase.from("page_events").select("id", { count: "exact", head: true }).eq("agent_id", agent.id).eq("event_type", "view").gte("created_at", thisMonthStart);
        const { count: waTaps } = await supabase.from("page_events").select("id", { count: "exact", head: true }).eq("agent_id", agent.id).eq("event_type", "whatsapp_tap").gte("created_at", thisMonthStart);
        const { count: leads } = await supabase.from("page_events").select("id", { count: "exact", head: true }).eq("agent_id", agent.id).eq("event_type", "lead_submit").gte("created_at", thisMonthStart);

        await sendWhatsAppReply(senderPhone,
          `📊 *Your Stats This Month*\n\n👁️ Profile Views: *${views || 0}*\n💬 WhatsApp Taps: *${waTaps || 0}*\n📩 Leads: *${leads || 0}*\n\nKeep sharing your link to grow! 🚀`
        );
      } else if (text.includes("my link") || text.includes("profile link")) {
        await sendWhatsAppReply(senderPhone,
          `Here's your profile link:\n\nhttps://sellingdubai-agents.netlify.app/a/${agent.slug}\n\nPaste it in your Instagram bio, WhatsApp status, or email signature.`
        );
      } else if (text.includes("remove last") || text.includes("delete last")) {
        const { data: lastProp } = await supabase
          .from("properties").select("id, title")
          .eq("agent_id", agent.id).order("created_at", { ascending: false }).limit(1).single();

        if (lastProp) {
          await supabase.from("properties").delete().eq("id", lastProp.id);
          await sendWhatsAppReply(senderPhone, `🗑️ Removed: *${lastProp.title}*`);
        } else {
          await sendWhatsAppReply(senderPhone, "No properties to remove.");
        }
      } else if (text.includes("social") || text.includes("template") || text.includes("instagram") || text.includes("tiktok")) {
        // Generate social templates for latest property
        const { data: lastProp } = await supabase
          .from("properties").select("title, description, price, property_type, bedrooms, location, features")
          .eq("agent_id", agent.id).order("created_at", { ascending: false }).limit(1).single();

        if (lastProp) {
          const parsed = {
            title: lastProp.title || '', price: lastProp.price ? `AED ${lastProp.price.toLocaleString()}` : null,
            type: lastProp.property_type, bedrooms: lastProp.bedrooms, bathrooms: null,
            area: lastProp.location, sqft: null, features: lastProp.features || [],
          };
          const aiResult = await generateListingWithClaude(parsed, agent.name);
          if (aiResult?.igCaption) {
            await sendWhatsAppReply(senderPhone, `📸 *Instagram caption for "${lastProp.title}":*\n\n${aiResult.igCaption}`);
          }
          if (aiResult?.tiktokCaption) {
            await sendWhatsAppReply(senderPhone, `🎬 *TikTok caption:*\n\n${aiResult.tiktokCaption}`);
          }
          if (!aiResult) {
            await sendWhatsAppReply(senderPhone, "Couldn't generate templates right now. Try again in a moment.");
          }
        } else {
          await sendWhatsAppReply(senderPhone, "No properties listed yet. Send a photo to create your first listing!");
        }
      } else {
        // Try to parse as property text (no photo)
        const parsed = parsePropertyCaption(msg.text?.body || "");
        if (parsed.title && parsed.title.length > 3) {
          const aiResult = await generateListingWithClaude(parsed, agent.name);
          const finalTitle = aiResult?.title || parsed.title;

          const { error: propErr } = await supabase
            .from("properties")
            .insert({
              agent_id: agent.id, title: finalTitle,
              description: aiResult?.description || null,
              property_type: parsed.type || null, bedrooms: parsed.bedrooms || null,
              location: parsed.area || null, features: parsed.features.length > 0 ? parsed.features : null,
              source: 'whatsapp', is_active: true, status: 'available',
            });

          if (!propErr) {
            let reply = `✅ Listed *${finalTitle}*\n\n💡 Send a photo next time for a better listing!`;
            if (aiResult?.igCaption) reply += `\n\n📸 *Instagram:*\n${aiResult.igCaption}`;
            await sendWhatsAppReply(senderPhone, reply);
          }
        } else {
          await sendWhatsAppReply(senderPhone,
            `Send a *photo with a caption* to list a property, or type *"help"* for commands.`
          );
        }
      }

      return new Response(JSON.stringify({ success: true }), { headers: CORS });
    }

    return new Response(JSON.stringify({ success: true }), { headers: CORS });
  } catch (e) {
    console.error("whatsapp-ingest error:", e);
    return new Response(JSON.stringify({ success: true }), { status: 200, headers: CORS });
  }
});
